CRICAI 2.0 — READY-TO-UPLOAD BUILD

CONTENTS
- index.html: complete standalone CricAI simulator website.

WHAT WAS FIXED / ADDED
- Fixed optional Custom Overs validation: leaving it blank now uses T20/ODI format.
- Added Save to History (keeps up to 20 saved match results in this browser's localStorage).
- Added Export Match JSON for each completed match.
- Preserved the original simulator's pitch, weather, toss, rain/DLS-style simulation, Super Over, awards and match summary features.

IMPORTANT LIMITATION
This ZIP contains the CricAI simulator you uploaded, not the separate Stumps Scoreboard source code.
It is a standalone static website. It is not yet connected to Stumps' database, player records, or APIs.
The current simulator reports phase-level innings summaries; it is not a delivery-by-delivery scoring engine.

HOW TO UPLOAD
1. Extract this ZIP on your phone/computer.
2. Open your GitHub repository CricAI 2.0.
3. Tap Add file -> Upload files (or the "uploading an existing file" link).
4. Upload index.html from the extracted folder.
5. Commit the changes.
6. To publish with GitHub Pages: repository Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
